'use strict';

/**
 * @ngdoc function
 * @name snowfirApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the snowfirApp
 */
angular.module('snowfirApp')
  .controller('MainCtrl', function($scope) {

  });
