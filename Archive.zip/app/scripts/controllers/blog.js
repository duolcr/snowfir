'use strict';

/**
 * @ngdoc function
 * @name snowfirApp.controller:BlogCtrl
 * @description
 * # BlogCtrl
 * Controller of the snowfirApp
 */
angular.module('snowfirApp')
  .controller('BlogCtrl', function ($scope) {

    });
