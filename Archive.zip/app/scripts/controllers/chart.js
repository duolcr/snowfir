'use strict';

/**
 * @ngdoc function
 * @name snowfirApp.controller:ChartCtrl
 * @description
 * # ChartCtrl
 * Controller of the snowfirApp
 */
angular.module('snowfirApp')
  .controller('ChartCtrl', function ($scope) {

  });
