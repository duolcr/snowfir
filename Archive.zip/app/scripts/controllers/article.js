'use strict';

/**
 * @ngdoc function
 * @name snowfirApp.controller:ArticleCtrl
 * @description
 * # ArticleCtrl
 * Controller of the snowfirApp
 */
angular.module('snowfirApp')
  .controller('ArticleCtrl', function($scope) {

    });
