'use strict';

/**
 * @ngdoc function
 * @name snowfirApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the snowfirApp
 */
angular.module('snowfirApp')
  .controller('AboutCtrl', function ($scope) {

  });
